BOARD DETAILS
-------------


BOARD NAME 			: PROC142A
REV				: A
DIMENSIONS			: 85 X 160.26 MM
NO.OF LAYERS			: 10
MINIMUM TRACEWIDTH/ CLEARANCE	: 3.2/3.2 MILS	
MINIMUM DRILL SIZE		: 8 MIL.
BOARD THICKNESS                 : 1.65 MM.
BOARD FINISH			: ENIG
BOARD MATERIAL                  : FR4
SOLDERMASK			: GREEN COLOUR

GERBER FORMAT

THE ARTWORK IS IN THE FOLLOWING FORMAT:
ODB++

           
IN CASE OF ANY CLARIFICATIONS PLEASE CONTACT 
ZUBAIR (9945155526)

MISTRAL SOLUTIONS PVT. LTD.
# 60, Adarsh Regent, 100 Ft. Ring Road,	                        
Domlur Extension,	                             
Bangalore - 560 071, INDIA	                                      
Ph: 91-80-3091 2600 Fax: 91-80-2535 6440	                      
www.mistralsolutions.com

